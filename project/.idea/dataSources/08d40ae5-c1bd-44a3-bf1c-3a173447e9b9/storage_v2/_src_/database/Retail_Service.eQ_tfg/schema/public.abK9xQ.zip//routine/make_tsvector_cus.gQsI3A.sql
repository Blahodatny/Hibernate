create function make_tsvector_cus(phone text, firstname text, lastname text, street text, city text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (SETWEIGHT(TO_TSVECTOR('english', Phone), 'A')) ||
         SETWEIGHT(TO_TSVECTOR('english', FirstName), 'B') ||
         SETWEIGHT(TO_TSVECTOR('english', LastName), 'B') ||
         SETWEIGHT(TO_TSVECTOR('english', Street), 'C') ||
         SETWEIGHT(TO_TSVECTOR('english', City), 'C');
END
$$;

alter function make_tsvector_cus(text, text, text, text, text) owner to postgres;

