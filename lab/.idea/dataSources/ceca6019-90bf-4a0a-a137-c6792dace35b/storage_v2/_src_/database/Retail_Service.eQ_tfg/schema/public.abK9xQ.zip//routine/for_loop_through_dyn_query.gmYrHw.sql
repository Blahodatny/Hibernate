create function for_loop_through_dyn_query(sort_type integer, n integer) returns void
  language plpgsql
as
$$
DECLARE
  rec   RECORD;
  query text;
BEGIN
  query := 'SELECT product_id, productType FROM products ';
  IF sort_type = 1 THEN
    query := query || 'ORDER BY product_id';
  ELSIF sort_type = 2 THEN
    query := query || 'ORDER BY productType';
  ELSE
    RAISE EXCEPTION 'Invalid sort type %s', sort_type;
  END IF;

  query := query || ' LIMIT $1';

  FOR rec IN EXECUTE query USING n
    LOOP
      RAISE NOTICE '% - %', rec.product_id, rec.productType;
    END LOOP;

END;
$$;

alter function for_loop_through_dyn_query(integer, integer) owner to postgres;

