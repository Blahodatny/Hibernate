create function make_tsvector_ord(tostreet text, tocity text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (SETWEIGHT(TO_TSVECTOR('english', ToStreet), 'D')) ||
         SETWEIGHT(TO_TSVECTOR('english', ToCity), 'D');
END
$$;

alter function make_tsvector_ord(text, text) owner to postgres;

