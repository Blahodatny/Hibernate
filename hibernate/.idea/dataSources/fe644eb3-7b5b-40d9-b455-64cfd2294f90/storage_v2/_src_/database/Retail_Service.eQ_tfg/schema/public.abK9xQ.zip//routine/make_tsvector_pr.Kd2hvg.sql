create function make_tsvector_pr(product_id text, producttype text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (setweight(to_tsvector('english', Product_ID), 'D')) ||
         setweight(to_tsvector('english', ProductType), 'D');
END
$$;

alter function make_tsvector_pr(text, text) owner to postgres;

